package br.com.devti.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.com.devti.core.Agencia;
import br.com.devti.core.Conta;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaDeposito extends JFrame {

	private JPanel contentPane;
	private JTextField numeroContaField;
	private JTextField ValorContaField;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JButton botaoDeposito;
    private Agencia agencia;
	
	
	public Agencia getAgencia() {
		return agencia;
	}

	public void setAgencia(Agencia agencia) {
		this.agencia = agencia;
		
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaDeposito frame = new TelaDeposito();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaDeposito() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		numeroContaField = new JTextField();
		numeroContaField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Numero da Conta");
		
		ValorContaField = new JTextField();
		ValorContaField.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Valor da Conta");
		
		lblNewLabel_2 = new JLabel("Deposito");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		botaoDeposito = new JButton("DEPOSITO");
		botaoDeposito.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero = numeroContaField.getText();
				double valor = Double.parseDouble(ValorContaField.getText());
				Conta contaEncontrada = agencia.buscarContaPorNumero(numero);
				if(contaEncontrada != null) {
					JOptionPane.showMessageDialog(null, contaEncontrada.depositar(valor));
					dispose();
				}else {
					JOptionPane.showMessageDialog(null, "Conta inexistente");
				}
			}
				
				
		
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGap(189)
					.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 69, Short.MAX_VALUE)
					.addGap(166))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(57)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(115)
							.addComponent(botaoDeposito, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(numeroContaField, GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE)
								.addComponent(ValorContaField, GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE))))
					.addGap(156))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(30)
					.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
					.addGap(31)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(numeroContaField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(ValorContaField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(35)
					.addComponent(botaoDeposito)
					.addContainerGap(59, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
