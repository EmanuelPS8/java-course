package br.com.devti.view;

import br.com.devti.core.Agencia;
import br.com.devti.core.Conta;

public class Principal {

	public static void main(String[] args) {
		Agencia agenciaN1 = new Agencia();
		
		Conta contaN1 = new Conta();
		contaN1.setNumeroConta("12341234");
		contaN1.setSaldoConta(100.0);
		agenciaN1.adicionarConta(contaN1);
		
		Conta contaN2 = new Conta();
		contaN2.setNumeroConta("123123123");
		contaN2.setSaldoConta(200.0);
		agenciaN1.adicionarConta(contaN2);
		
		Conta contaN3 = new Conta();
		contaN3.setNumeroConta("234234234");
		contaN3.setSaldoConta(300.0);
		agenciaN1.adicionarConta(contaN3);
		
		TelaPrincipal t1 = new TelaPrincipal();
		t1.setVisible(true);
		t1.setAgencia(agenciaN1);
	}
}