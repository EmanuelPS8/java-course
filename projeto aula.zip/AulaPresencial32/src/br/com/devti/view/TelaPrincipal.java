package br.com.devti.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.com.devti.core.Agencia;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JSpinner;

public class TelaPrincipal extends JFrame {

	private JPanel contentPane;

	private Agencia agencia;
	
	
	public Agencia getAgencia() {
		return agencia;
	}

	public void setAgencia(Agencia agencia) {
		this.agencia = agencia;
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPrincipal() {
		setBackground(Color.RED);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\unisul.UNS12DT100225\\Desktop\\baixados.jfif"));
		setTitle("                                           BANCO SEI LA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.RED);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnVerDeposito = new JButton("DEPOSITO");
		btnVerDeposito.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaDeposito td = new TelaDeposito();
				td.setVisible(true);
				td.setAgencia(agencia);
				
			}
		});
		btnVerDeposito.setBackground(new Color(255, 0, 255));
		btnVerDeposito.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JButton botaoVerSaldo = new JButton("SALDO");
		botaoVerSaldo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaSaldo tl = new TelaSaldo();
				tl.setVisible(true);
				tl.setAgencia(agencia);
			}
		});
		botaoVerSaldo.setBackground(new Color(255, 0, 255));
		botaoVerSaldo.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JButton btnSacar = new JButton("SAQUE");
		btnSacar.setBackground(new Color(255, 0, 255));
		btnSacar.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnSacar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaSaque ts = 	new TelaSaque();
				ts.setVisible(true);
				ts.setAgencia(agencia);
			}
		});
		
		JLabel lblNewLabel = new JLabel("CLIQUE NA OP\u00C7AO QUE DESEJA FAZER");
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(151)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnSacar, GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
						.addComponent(botaoVerSaldo, GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
						.addComponent(btnVerDeposito, GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE))
					.addGap(167))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(104)
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
					.addGap(116))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 18, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnVerDeposito, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(botaoVerSaldo, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnSacar, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(57, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
