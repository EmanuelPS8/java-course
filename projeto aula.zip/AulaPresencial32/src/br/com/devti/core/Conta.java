package br.com.devti.core;

public class Conta {

	private String numeroConta;
	private double saldoConta;
	
	
	public Conta() {
		saldoConta = 0.0;
	}
	
	public String getNumeroConta() {
		return numeroConta;
	}
	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}
	public Double getSaldoConta() {
		return saldoConta;
	}
	public void setSaldoConta(Double saldoConta) {
		this.saldoConta = saldoConta;
	}
	
	public String depositar(double valor) {
		if(valor > 0) {
			this.saldoConta = this.saldoConta + valor;
			return "O valor foi depositado com sucesso";
		}else {
			return "O valor n�o pode ser negativo";
		}
	}
	
	public String sacar(double valorSaque) {
		if(valorSaque < saldoConta && valorSaque > 0){
			valorSaque -= saldoConta;
			return "Saque feito com sucesso";
		}else {
			return "Nao foi possivel sacar Saldo insuficiente";
	             }
		}
	
}
