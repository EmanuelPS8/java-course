package br.com.devti.core;

import java.util.ArrayList;

public class Agencia {

		
	private ArrayList<Conta> listaContas;
	
	public Agencia() {
		
	 listaContas = new ArrayList<>();
	}

	public ArrayList<Conta> getListaContas() {
		return listaContas;
	}

	public void adicionarConta(Conta conta) {
		listaContas.add(conta);
	}
	
	public Conta buscarContaPorNumero(String numeroCT) {
		for (Conta conta : listaContas) {
			if(numeroCT.equals(conta.getNumeroConta())){
				return conta;
			}
		}
		return null;
	}
		
	
}
